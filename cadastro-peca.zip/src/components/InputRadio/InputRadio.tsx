export function InputRadio() {
  return (
    <div>
      <h1>asdf</h1>
    </div>
  )
}
