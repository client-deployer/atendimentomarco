// import {
//   forwardRef,
//   ForwardRefRenderFunction,
//   InputHTMLAttributes,
// } from "react"
// import Select from "react-select/dist/declarations/src/Select"
// import { ISampleDataList } from "../../interfaces"
// import { Container, InputWrapper } from "./FormSelect.styled"

// interface IFormInput extends InputHTMLAttributes<HTMLInputElement> {
//   label?: string
//   errors?: string
//   datalist?: ISampleDataList[]
// }

// type Ref = HTMLInputElement

// const FormSelectComponent: ForwardRefRenderFunction<Ref, IFormInput> = (
//   { label, errors, datalist, ...props }: IFormInput,
//   ref,
// ) => {
//   return (
//     <Container>
//       <Select />
//       {errors && <p>{errors}</p>}
//     </Container>
//   )
// }

// export const FormSelect = forwardRef(FormSelectComponent)
