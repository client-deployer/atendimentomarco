import styled, { css } from "styled-components"

const buttonVariants = {
  leftIcon: css`
    flex-direction: row-reverse;
  `,
}

export type ButtonVariants = keyof typeof buttonVariants

export interface IButton {
  variant?: ButtonVariants
}

export const Button = styled.button<IButton>`
  display: flex;
  justify-content: space-between;
  align-items: center;
  ${({ variant }) => variant && buttonVariants[variant]};
  gap: 0.25rem;
  max-width: 7.5rem;
  width: 100%;

  background-color: #0051b5;
  color: #fff;
  padding: 0.625rem 1.25rem;
  border-radius: 4px;
  font-size: 1rem;
`
