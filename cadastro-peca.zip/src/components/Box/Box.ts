import styled, { css } from "styled-components"

const boxVariants = {
  row: css`
    flex-direction: row;
    justify-content: space-between;
  `,
  column: css`
    flex-direction: column;
    justify-content: space-between;
  `,
  dualButton: css`
    section {
      justify-content: space-between;
    }
  `,
  buttonStart: css`
    section {
      justify-content: flex-start;
    }
  `,
  buttonEnd: css`
    section {
      justify-content: flex-end;
    }
  `,
}

type IVariants = keyof typeof boxVariants

interface IBox {
  variants: IVariants
}

export const Box = styled.section<IBox>`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  max-width: 400px;
  width: 100%;
  gap: 0.5rem;
  margin: 2rem 1rem;
  padding: 1rem 1.5rem;
  border-radius: 8px;
  box-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);

  background-color: #fff;

  section {
    padding-top: 1rem;
    display: flex;
    width: 100%;
  }

  ${({ variants }) => variants && boxVariants[variants]};
`
