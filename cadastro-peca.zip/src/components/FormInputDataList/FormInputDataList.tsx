import {
  forwardRef,
  ForwardRefRenderFunction,
  InputHTMLAttributes,
  useRef,
  useState,
} from "react"
import { ISampleDataList } from "../../interfaces"
import { Container, Datalist, InputWrapper } from "./FormInputDataList.styled"

import { useOutsideAlerter } from "../../features/utils/hooks"

interface IFormInput extends InputHTMLAttributes<HTMLInputElement> {
  label: string
  errors?: string
  datalist: ISampleDataList[]
  content: string
}

type Ref = HTMLInputElement

const FormInputDataListComponent: ForwardRefRenderFunction<Ref, IFormInput> = (
  { label, errors, datalist, content, ...props }: IFormInput,
  ref,
) => {
  const [selectedOption, setSelectedOption] = useState("")

  const [isOpen, setIsOpen] = useState(false)

  const handleSetIsOpen = () => {
    setIsOpen(!isOpen)
  }

  const handleSetSelectedOption = (option: string) => {
    setSelectedOption(option)
    handleSetIsOpen()
  }

  const selectRef = useRef(null)
  useOutsideAlerter(selectRef)

  return (
    <Container>
      <InputWrapper>
        <h3>{label}</h3>
        <input
          ref={ref}
          value={selectedOption}
          onFocus={() => handleSetIsOpen()}
          id={label}
          list={label}
          {...props}
        />
        <label htmlFor={label}>Digitar</label>
        {isOpen && (
          <Datalist ref={selectRef} id={label}>
            <input type="text" />
            <ul>
              {datalist.map((data, key) => {
                return (
                  <li
                    onClick={() => handleSetSelectedOption(data.option)}
                    key={key}
                  >
                    {data.option}
                  </li>
                )
              })}
            </ul>
          </Datalist>
        )}
      </InputWrapper>
      <div>{errors && <p>{errors}</p>}</div>
    </Container>
  )
}

// ?.filter((data) => data.option.includes(content))

export const FormInputDataList = forwardRef(FormInputDataListComponent)
