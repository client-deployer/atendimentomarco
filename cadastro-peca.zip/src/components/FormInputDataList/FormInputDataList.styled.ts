import styled from "styled-components"

export const Container = styled.div`
  p {
    color: #dc2626;
    margin: 10px 0;
  }
`

export const InputWrapper = styled.div`
  display: flex;
  position: relative;
  flex-direction: column;

  label {
    position: absolute;
    top: 60%;
    left: 0;
    transform: translateY(-50%);
    font-size: 14px;
    transition: all 200ms;
    pointer-events: none;
    opacity: 0.8;
  }

  input {
    position: relative;
    border: 0;
    border-bottom: 1px solid #78716c;
    outline: none;
    padding: 10px 0;
    width: 100%;
  }
`

export const InputFile = styled.label`
  display: flex;
  align-items: center;
  gap: 10px;

  cursor: pointer;

  input[type="file"] {
    display: none;
  }
`

export const Datalist = styled.div`
  position: absolute;
  top: 90%;
  background-color: #fff;
  box-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
  border-radius: 4px;

  input {
    border: 1px solid red;
    border-radius: 4px;
  }

  ul {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
    padding: 0;
    width: 100%;
    max-height: 10.75rem;
    z-index: 2;
    overflow-y: auto;
  }

  li {
    transition: all 0.15s;
    padding: 0.5rem 0.75rem;
    cursor: pointer;

    &:hover {
      background-color: #e2e2e2;
    }
  }
`
