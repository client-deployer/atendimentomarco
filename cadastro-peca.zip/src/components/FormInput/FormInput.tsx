import {
  forwardRef,
  ForwardRefRenderFunction,
  InputHTMLAttributes,
} from "react"
import { ISampleDataList } from "../../interfaces"
import { Container, InputWrapper } from "./FormInput.styled"

interface IFormInput extends InputHTMLAttributes<HTMLInputElement> {
  label?: string
  errors?: string
  colorWhite?: boolean
  datalist?: ISampleDataList[]
}

type Ref = HTMLInputElement

const FormInputComponent: ForwardRefRenderFunction<Ref, IFormInput> = (
  { label, errors, datalist, colorWhite, ...props }: IFormInput,
  ref,
) => {
  return (
    <Container>
      <InputWrapper colorWhite={colorWhite}>
        {label && <h3>{label}</h3>}
        <input
          ref={ref}
          placeholder={!label ? "Digitar" : ""}
          id={label}
          list={label}
          {...props}
        />
        {label && <label htmlFor={label}>Digitar</label>}
        {datalist && (
          <datalist id={label}>
            {datalist?.map((data, key) => {
              return (
                <option key={key} value={data.value}>
                  {data.option}
                </option>
              )
            })}
          </datalist>
        )}
      </InputWrapper>
      {errors && <p>{errors}</p>}
    </Container>
  )
}

export const FormInput = forwardRef(FormInputComponent)
