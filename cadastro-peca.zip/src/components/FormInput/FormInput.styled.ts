import styled from "styled-components"

interface IInputWrapper {
  colorWhite?: boolean
}

export const Container = styled.div`
  p {
    color: #dc2626;
    margin: 10px 0;
  }
`

export const InputWrapper = styled.div<IInputWrapper>`
  display: flex;
  position: relative;
  flex-direction: column;

  label {
    position: absolute;
    top: 60%;
    left: 0;
    transform: translateY(-50%);
    font-size: 14px;
    transition: all 200ms;
    pointer-events: none;
    opacity: 0.8;
  }

  input {
    ${({ colorWhite }) => (colorWhite ? `color: white` : `color: black`)};
    background: transparent;
    position: relative;
    border: 0;
    outline: none;
    border-bottom: 1px solid;
    ${({ colorWhite }) =>
      colorWhite ? `border-color: #fff` : `border-color: #78716c`};
    font-size: 16;
    padding: 10px 0;
    width: 100%;

    &::placeholder {
      color: white;
    }
  }
`
