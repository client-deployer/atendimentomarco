import styled from "styled-components"

export const Container = styled.div`
  span {
    color: #dc2626;
  }
`

export const InputWrapper = styled.label`
  display: flex;
  align-items: center;
  gap: 0.625rem;

  cursor: pointer;

  input[type="file"] {
    display: none;
  }
`
