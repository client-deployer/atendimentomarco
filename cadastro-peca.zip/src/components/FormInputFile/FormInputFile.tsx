import { FileText } from "phosphor-react"
import React from "react"

import { IMultiStepForm } from "../../interfaces/index"

import {
  forwardRef,
  ForwardRefRenderFunction,
  InputHTMLAttributes,
} from "react"

import { Container, InputWrapper } from "./FormInputFile.styled"

interface IFormInputFile extends InputHTMLAttributes<HTMLInputElement> {
  errors?: string
  currentFormData: IMultiStepForm
}

type Ref = HTMLInputElement

const FormInputFileComponent: ForwardRefRenderFunction<Ref, IFormInputFile> = (
  { errors, currentFormData, ...props }: IFormInputFile,
  ref,
) => {
  return (
    <Container>
      <InputWrapper>
        <input id="incomeReceipt" type="file" ref={ref} {...props} />
        <FileText size={32} />
        <p>
          {!currentFormData.incomeReceipt
            ? "Nota fiscal de entrada"
            : "Nota fiscal de entrada: " +
              currentFormData.incomeReceipt[0].name}
        </p>
      </InputWrapper>
      {errors && <span>{errors}</span>}
    </Container>
  )
}

export const FormInputFile = forwardRef(FormInputFileComponent)
