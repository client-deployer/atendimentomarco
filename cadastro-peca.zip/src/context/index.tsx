import {
  createContext,
  Dispatch,
  ReactNode,
  SetStateAction,
  useState,
} from "react"
import { IMultiStepForm } from "../interfaces"

interface IStepForm {
  currentStep: number
  currentFormData: IMultiStepForm
  handleIncreaseStep: () => void
  handleDecreaseStep: () => void
  setCurrentFormData: Dispatch<SetStateAction<IMultiStepForm>>
}

export const StepForm = createContext({} as IStepForm)

interface StepFormChildren {
  children: ReactNode
}

export function StepFormProvider({ children }: StepFormChildren) {
  const [currentStep, setCurrentStep] = useState(0)
  const [currentFormData, setCurrentFormData] = useState<IMultiStepForm>(
    {} as IMultiStepForm,
  )

  const handleIncreaseStep = () => {
    setCurrentStep(currentStep + 1)
  }

  const handleDecreaseStep = () => {
    setCurrentStep(currentStep - 1)
  }

  const handleUpdateCurrentFormData = (data: any) => {
    setCurrentFormData(data)
  }

  return (
    <StepForm.Provider
      value={{
        currentStep,
        currentFormData,
        handleIncreaseStep,
        handleDecreaseStep,
        setCurrentFormData,
      }}
    >
      {children}
    </StepForm.Provider>
  )
}
