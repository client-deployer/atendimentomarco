import { Button, FormInput } from "../../components"
import { BsChevronLeft, BsChevronRight } from "react-icons/bs"
import { Box } from "../../components/Box"
import { useContext } from "react"
import { StepForm } from "../../context"
import { useFormContext } from "react-hook-form"
import { floatMask, numberMask } from "../utils/masks"
import { IMultiStepForm } from "../../interfaces"

export function ThirdStep() {
  const {
    handleDecreaseStep,
    setCurrentFormData,
    currentFormData,
    handleIncreaseStep,
  } = useContext(StepForm)

  const {
    register,
    setValue,
    formState: { errors },
  } = useFormContext<IMultiStepForm>()

  return (
    <Box variants="dualButton">
      <h2>Embalagem itens</h2>
      <FormInput
        {...register("qtdembalagem", {
          onChange: (event) => {
            setValue("qtdembalagem", numberMask(event))
            setCurrentFormData({
              ...currentFormData,
              qtdembalagem: parseInt(event.target.value),
            })
          },
        })}
        errors={errors && errors.qtdembalagem?.message}
        label="Qtd embalagem"
      />
      <FormInput
        {...register("pesoitem", {
          onChange: (event) => {
            setValue("pesoitem", floatMask(event))
            setCurrentFormData({
              ...currentFormData,
              pesoitem: parseFloat(event.target.value),
            })
          },
        })}
        errors={errors && errors.pesoitem?.message}
        label="Peso do item"
      />
      <FormInput
        {...register("unidademedida", {
          onChange: (event) => {
            setCurrentFormData({
              ...currentFormData,
              unidademedida: event.target.value,
            })
          },
        })}
        errors={errors && errors.unidademedida?.message}
        label="Unidade de conversão"
      />
      <section>
        <Button onClick={() => handleDecreaseStep()}>
          <BsChevronLeft />
          Anterior
        </Button>
        <Button onClick={() => handleIncreaseStep()}>
          Próximo
          <BsChevronRight />
        </Button>
      </section>
    </Box>
  )
}
