import { Button, FormInput, Box } from "../../components"
import { BsChevronRight } from "react-icons/bs"
import { useContext } from "react"
import { StepForm } from "../../context"
import { Controller, useFormContext } from "react-hook-form"
import { IMultiStepForm, ISampleDataList } from "../../interfaces"
import Select from "react-select/dist/declarations/src/Select"

const sampleDataList: ISampleDataList[] = [
  { option: "batata", value: 1 },
  { option: "barata", value: 2 },
  { option: "cenoura", value: 3 },
  { option: "cebola", value: 4 },
  { option: "cereal", value: 5 },
  { option: "batata", value: 1 },
  { option: "barata", value: 2 },
  { option: "cenoura", value: 3 },
  { option: "cebola", value: 4 },
  { option: "cereal", value: 5 },
  { option: "batata", value: 1 },
  { option: "barata", value: 2 },
  { option: "cenoura", value: 3 },
  { option: "cebola", value: 4 },
  { option: "cereal", value: 5 },
]

export function FirstStep() {
  const { handleIncreaseStep, setCurrentFormData, currentFormData } =
    useContext(StepForm)

  const {
    register,
    setValue,
    control,
    formState: { errors },
  } = useFormContext<IMultiStepForm>()

  interface ICategory {
    value: string
    label: string
  }

  return (
    <Box variants="buttonEnd">
      <h1>Iniciar cadastro de peça</h1>
      <h2>Código de tributação</h2>
      <FormInput
        {...register("codigotributacaoe", {
          onChange: (event) => {
            // setValue("codigotributacaoe", numberMask(event))
            setCurrentFormData({
              ...currentFormData,
              codigotributacaoe: event.target.value,
            })
          },
        })}
        datalist={sampleDataList}
        label="Entrada"
        errors={errors && errors.codigotributacaoe?.message}
      />
      <FormInput
        {...register("codigotributacaos", {
          onChange: (event) => {
            setCurrentFormData({
              ...currentFormData,
              codigotributacaos: event.target.value,
            })
          },
        })}
        label="Saída"
        errors={errors && errors.codigotributacaos?.message}
      />
      {/* <Controller
        control={control}
        render={({ field: { onChange, value, name, ref } }) => (
          <Select
            inputRef={ref}
            value={sampleDataList.find((c) => c.option === value)}
            name={name}
            options={sampleDataList}
            onChange={(selectedOption: ISampleDataList) => {
              onChange(selectedOption.option)
            }}
          />
        )}
        name="codigotributacaoe"
      /> */}
      <FormInput
        {...register("codigotributacaoe", {
          onChange: (event) => {
            setCurrentFormData({
              ...currentFormData,
              codigotributacaoe: event.target.value,
            })
          },
        })}
        label="Saída"
        errors={errors && errors.codigotributacaoe?.message}
      />
      <section>
        <Button onClick={() => handleIncreaseStep()}>
          Próximo
          <BsChevronRight />
        </Button>
      </section>
    </Box>
  )
}
