import { Button, FormInput } from "../../components"
import { BsChevronLeft, BsChevronRight } from "react-icons/bs"
import { Box } from "../../components/Box"
import { useContext } from "react"
import { StepForm } from "../../context"
import { useFormContext } from "react-hook-form"
import {
  Container,
  Table,
  TableContainer,
  TableWrapper,
} from "./FifthStep.styled"
import { IMultiStepForm } from "../../interfaces"
import { CircleNotch, Plus } from "phosphor-react"
import { FieldSet } from "../SixthStep/styles"

export function FifthStep() {
  const {
    handleDecreaseStep,
    setCurrentFormData,
    currentFormData,
    handleIncreaseStep,
  } = useContext(StepForm)

  const {
    register,
    setValue,
    watch,
    formState: { errors },
  } = useFormContext<IMultiStepForm>()

  return (
    <Box variants="dualButton">
      <h2>Detalhes</h2>
      <FormInput
        {...register("desitemestoque", {
          onChange: (event) => {
            setCurrentFormData({
              ...currentFormData,
              desitemestoque: event.target.value,
            })
          },
        })}
        label="Descrição do item"
        errors={errors && errors.desitemestoque?.message}
      />
      <FieldSet>
        <legend>Descrição completa</legend>
        {currentFormData.grupo &&
        currentFormData.categoria &&
        currentFormData.desitemestoque ? (
          currentFormData.grupo
            .concat(", ", currentFormData.categoria)
            .concat(", ", currentFormData.desitemestoque)
        ) : (
          <CircleNotch size={22} color="#6d6d6d" />
        )}
      </FieldSet>
      <FormInput
        {...register("utilizacao", {
          onChange: (event) => {
            setCurrentFormData({
              ...currentFormData,
              utilizacao: event.target.value,
            })
          },
        })}
        label="Utilização"
        errors={errors && errors.utilizacao?.message}
      />
      <FormInput
        {...register("codigofabrica", {
          onChange: (event) => {
            setCurrentFormData({
              ...currentFormData,
              codigofabrica: event.target.value,
            })
          },
        })}
        label="Código de fábrica"
        errors={errors && errors.codigofabrica?.message}
      />
      <section>
        <Button onClick={() => handleDecreaseStep()}>
          <BsChevronLeft />
          Anterior
        </Button>
        <Button onClick={() => handleIncreaseStep()}>
          Próximo
          <BsChevronRight />
        </Button>
      </section>
    </Box>
    // <Container>
    //   <TableContainer>
    //     <TableWrapper>
    //       <h2>Itens relacionados</h2>
    //       <Table>
    //         <thead>
    //           <tr>
    //             <td>Código</td>
    //             <td>Descrição</td>
    //             <td>Disponível</td>
    //           </tr>
    //           <tr>
    //             <td>
    //               <FormInput colorWhite />
    //             </td>
    //             <td>
    //               <FormInput colorWhite />
    //             </td>
    //             <td>
    //               <button>
    //                 <Plus />
    //               </button>
    //             </td>
    //           </tr>
    //         </thead>
    //         <tbody>
    //           <tr>
    //             <td>123</td>
    //             <td>batatinha</td>
    //             <td>Sim</td>
    //           </tr>
    //           <tr>
    //             <td>123</td>
    //             <td>batatinha</td>
    //             <td>Sim</td>
    //           </tr>
    //           <tr>
    //             <td>123</td>
    //             <td>batatinha</td>
    //             <td>Sim</td>
    //           </tr>
    //           <tr>
    //             <td>123</td>
    //             <td>batatinha</td>
    //             <td>Sim</td>
    //           </tr>
    //           <tr>
    //             <td>123</td>
    //             <td>batatinha</td>
    //             <td>Sim</td>
    //           </tr>
    //           <tr>
    //             <td>123</td>
    //             <td>batatinha</td>
    //             <td>Sim</td>
    //           </tr>
    //           <tr>
    //             <td>123</td>
    //             <td>batatinha</td>
    //             <td>Sim</td>
    //           </tr>
    //           <tr>
    //             <td>123</td>
    //             <td>batatinha</td>
    //             <td>Sim</td>
    //           </tr>
    //           <tr>
    //             <td>123</td>
    //             <td>batatinha</td>
    //             <td>Sim</td>
    //           </tr>
    //           <tr>
    //             <td>123</td>
    //             <td>batatinha</td>
    //             <td>Sim</td>
    //           </tr>
    //           <tr>
    //             <td>123</td>
    //             <td>batatinha</td>
    //             <td>Sim</td>
    //           </tr>
    //           <tr>
    //             <td>123</td>
    //             <td>batatinha</td>
    //             <td>Sim</td>
    //           </tr>
    //           <tr>
    //             <td>123</td>
    //             <td>batatinha</td>
    //             <td>Sim</td>
    //           </tr>
    //           <tr>
    //             <td>123</td>
    //             <td>batatinha</td>
    //             <td>Sim</td>
    //           </tr>
    //           <tr>
    //             <td>123</td>
    //             <td>batatinha</td>
    //             <td>Sim</td>
    //           </tr>
    //         </tbody>
    //       </Table>
    //     </TableWrapper>
    //     <TableWrapper>
    //       <h2>Itens dependentes</h2>
    //       <Table>
    //         <thead>
    //           <tr>
    //             <td>Código público</td>
    //             <td>Referência de fábrica</td>
    //             <td>Disponível</td>
    //           </tr>
    //           <tr>
    //             <td>
    //               <FormInput colorWhite />
    //             </td>
    //             <td>
    //               <FormInput colorWhite />
    //             </td>
    //             <td>
    //               <button>
    //                 <Plus />
    //               </button>
    //             </td>
    //           </tr>
    //         </thead>
    //         <tbody>
    //           <tr>
    //             <td>123</td>
    //             <td>batatinha</td>
    //             <td>Sim</td>
    //           </tr>
    //           <tr>
    //             <td>123</td>
    //             <td>batatinha</td>
    //             <td>Sim</td>
    //           </tr>
    //           <tr>
    //             <td>123</td>
    //             <td>batatinha</td>
    //             <td>Sim</td>
    //           </tr>
    //           <tr>
    //             <td>123</td>
    //             <td>batatinha</td>
    //             <td>Sim</td>
    //           </tr>
    //           <tr>
    //             <td>123</td>
    //             <td>batatinha</td>
    //             <td>Sim</td>
    //           </tr>
    //           <tr>
    //             <td>123</td>
    //             <td>batatinha</td>
    //             <td>Sim</td>
    //           </tr>
    //           <tr>
    //             <td>123</td>
    //             <td>batatinha</td>
    //             <td>Sim</td>
    //           </tr>
    //           <tr>
    //             <td>123</td>
    //             <td>batatinha</td>
    //             <td>Sim</td>
    //           </tr>
    //           <tr>
    //             <td>123</td>
    //             <td>batatinha</td>
    //             <td>Sim</td>
    //           </tr>
    //           <tr>
    //             <td>123</td>
    //             <td>batatinha</td>
    //             <td>Sim</td>
    //           </tr>
    //           <tr>
    //             <td>123</td>
    //             <td>batatinha</td>
    //             <td>Sim</td>
    //           </tr>
    //           <tr>
    //             <td>123</td>
    //             <td>batatinha</td>
    //             <td>Sim</td>
    //           </tr>
    //           <tr>
    //             <td>123</td>
    //             <td>batatinha</td>
    //             <td>Sim</td>
    //           </tr>
    //           <tr>
    //             <td>123</td>
    //             <td>batatinha</td>
    //             <td>Sim</td>
    //           </tr>
    //           <tr>
    //             <td>123</td>
    //             <td>batatinha</td>
    //             <td>Sim</td>
    //           </tr>
    //         </tbody>
    //       </Table>
    //     </TableWrapper>
    //   </TableContainer>
    // </Container>
  )
}
