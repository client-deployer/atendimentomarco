import styled from "styled-components"

export const Container = styled.div`
  display: flex;
  gap: 2rem;
  align-items: flex-start;
  justify-content: flex-start;
`

export const TableWrapper = styled.div`
  h2 {
    padding-bottom: 10px;
  }
`

export const TableContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: 1rem;
  margin: 2rem 0;
`

export const Table = styled.table`
  font-size: 1rem;
  border-collapse: collapse;
  box-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);

  button {
    all: unset;
    display: flex;
    padding: 2px;
    border-radius: 4px;
    color: black;
    background-color: #fff;
  }

  tbody {
    display: block;
    max-height: 10rem;
    overflow-y: scroll;
  }

  thead,
  tbody tr {
    display: table;
    max-width: 500px;
    width: 100%;
    table-layout: fixed;
  }

  thead {
    color: #fff;
    background-color: #0051b5;
  }

  td {
    padding: 10px;
  }

  tbody tr:nth-child(even) {
    background-color: #e2e2e2;
  }
`
