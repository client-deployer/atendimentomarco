import { Button, FormInput, FormInputFile } from "../../components"
import { BsChevronLeft, BsChevronRight } from "react-icons/bs"
import { Box } from "../../components/Box"
import { useContext } from "react"
import { StepForm } from "../../context"
import { useFormContext } from "react-hook-form"
import { IMultiStepForm } from "../../interfaces"

export function SecondStep() {
  const {
    handleIncreaseStep,
    handleDecreaseStep,
    currentFormData,
    setCurrentFormData,
  } = useContext(StepForm)

  const {
    register,
    setValue,
    formState: { errors },
  } = useFormContext<IMultiStepForm>()

  return (
    <Box variants="dualButton">
      <h2>Preços</h2>
      <FormInput
        {...register("precopublicoatual", {
          onChange: (event) => {
            setCurrentFormData({
              ...currentFormData,
              precopublicoatual: parseFloat(event.target.value),
            })
          },
        })}
        label="Público atual"
        errors={errors && errors.precopublicoatual?.message}
      />
      <FormInput
        {...register("precoavista", {
          onChange: (event) => {
            setCurrentFormData({
              ...currentFormData,
              precoavista: parseFloat(event.target.value),
            })
          },
        })}
        label="À Vista"
        errors={errors && errors.precoavista?.message}
      />
      <FormInput
        {...register("precogarantia", {
          onChange: (event) => {
            setCurrentFormData({
              ...currentFormData,
              precogarantia: parseFloat(event.target.value),
            })
          },
        })}
        label="Garantia"
        errors={errors && errors.precogarantia?.message}
        type="number"
      />
      {/* <FormInputFile
        currentFormData={currentFormData}
        {...register("incomeReceipt", {
          onChange: (e) => {
            setCurrentFormData({
              ...currentFormData,
              incomeReceipt: e.target.files,
            })
          },
        })}
        errors={errors && errors.incomeReceipt?.message}
      /> */}
      <section>
        <Button onClick={() => handleDecreaseStep()}>
          <BsChevronLeft />
          Anterior
        </Button>
        <Button onClick={() => handleIncreaseStep()}>
          Próximo
          <BsChevronRight />
        </Button>
      </section>
    </Box>
  )
}
