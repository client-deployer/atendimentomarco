interface IDataListReducer {
  selectedIndex: number
}
export const reducer = (state: IDataListReducer, action: any) => {
  switch (action.type) {
    case "arrowUp":
      return {
        selectedIndex:
          state.selectedIndex !== 0
            ? state.selectedIndex - 1
            : action.list.length - 1,
      }
  }
}
