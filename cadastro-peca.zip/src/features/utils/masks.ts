import { ChangeEvent } from "react"

export const floatMask = (e: ChangeEvent<HTMLInputElement>) => {
  let value = e.target.value.replace(/[^0-9.]/g, "")

  if (value.split(".").length > 2) {
    return parseFloat(value.replace(/[^0-9]/g, ""))
  } else {
    return parseFloat(value)
  }
}

export const numberMask = (e: ChangeEvent<HTMLInputElement>) => {
  let value = e.target.value.replace(/\D/g, "")

  return isNaN(parseInt(value)) ? 0 : parseInt(value)
}
