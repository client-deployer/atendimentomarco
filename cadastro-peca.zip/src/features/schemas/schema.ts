import * as yup from "yup"

export const schema = yup.object().shape({
  codigotributacaoe: yup
    .string()
    .required("Insira o código de tributação!")
    .typeError("Insira o código de tributação!"),
  codigotributacaos: yup.string().required("Insira o código de tributação!"),
  precopublicoatual: yup
    .number()
    .required("Campo obrigatório!")
    .typeError("Campo obrigatório!"),
  precoavista: yup
    .number()
    .required("Campo obrigatório!")
    .typeError("Campo obrigatório!"),
  precogarantia: yup
    .number()
    .required("Campo obrigatório!")
    .typeError("Campo obrigatório!"),
  // incomeReceipt: yup.mixed().required("Por favor, selecione o arquivo!"),
  qtdembalagem: yup
    .number()
    .required("Campo obrigatório!")
    .typeError("Campo obrigatório!"),
  pesoitem: yup
    .number()
    .required("Campo obrigatório!")
    .typeError("Campo obrigatório!"),
  unidademedida: yup.string().required("Campo obrigatório!"),
  marca: yup.string().required("Campo obrigatório"),
  categoria: yup
    .string()
    .required("Campo obrigatório!")
    .typeError("Campo obrigatório!"),
  grupo: yup.string().required("Campo obrigatório"),
  desitemestoque: yup.string().required("Campo obrigatório"),
  utilizacao: yup.string().required("Campo obrigatório"),
  codigofabrica: yup.string().required("Campo obrigatório"),
  origem: yup.string().required("Campo obrigatório!"),
  posicaofiscal: yup.string().required("Campo obrigatório!"),
  cogsegmentoncm: yup.string().required("Campo obrigatório!"),
  basepis: yup.string().required("Campo obrigatório!"),
  basecofins: yup.string().required("Campo obrigatório!"),
  cest: yup.string().required("Campo obrigatório!"),
  pctpisimporta: yup.number().required("Campo obrigatório!"),
  pctcofinsimporta: yup.number().required("Campo obrigatório!"),
  codeangtin: yup.number().required("Campo obrigatório!"),
  aliquotaipi: yup.number().required("Campo obrigatório!"),
  impostoimportacao: yup.number().required("Campo obrigatório!"),
  aliqmajor: yup.number().required("Campo obrigatório!"),
  codeantrib: yup.number().required("Campo obrigatório!"),
})
