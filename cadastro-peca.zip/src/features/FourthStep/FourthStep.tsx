import { Button, FormInput } from "../../components"
import { BsChevronLeft, BsChevronRight } from "react-icons/bs"
import { Box } from "../../components/Box"
import { useContext } from "react"
import { StepForm } from "../../context"
import { useFormContext } from "react-hook-form"
import { floatMask } from "../utils/masks"
import { IMultiStepForm } from "../../interfaces"

export function FourthStep() {
  const {
    handleDecreaseStep,
    setCurrentFormData,
    handleIncreaseStep,
    currentFormData,
  } = useContext(StepForm)

  const {
    register,
    setValue,
    formState: { errors },
  } = useFormContext<IMultiStepForm>()

  return (
    <Box variants="dualButton">
      <h2>Marca, categoria e grupo</h2>
      <FormInput
        {...register("marca", {
          onChange: (event) => {
            setCurrentFormData({
              ...currentFormData,
              marca: event.target.value,
            })
          },
        })}
        label="Marca"
        errors={errors && errors.marca?.message}
      />
      <FormInput
        {...register("categoria", {
          onChange: (event) => {
            setCurrentFormData({
              ...currentFormData,
              categoria: event.target.value,
            })
          },
        })}
        label="Categoria"
        errors={errors && errors.categoria?.message}
      />
      <FormInput
        {...register("grupo", {
          onChange: (event) => {
            setCurrentFormData({
              ...currentFormData,
              grupo: event.target.value,
            })
          },
        })}
        label="Grupo"
        errors={errors && errors.grupo?.message}
      />
      <FormInput
        {...register("grupodesconto", {
          onChange: (event) => {
            setCurrentFormData({
              ...currentFormData,
              grupodesconto: event.target.value,
            })
          },
        })}
        label="Grupo de desconto"
        errors={errors && errors.grupodesconto?.message}
      />
      <section>
        <Button onClick={() => handleDecreaseStep()}>
          <BsChevronLeft />
          Anterior
        </Button>
        <Button onClick={() => handleIncreaseStep()}>
          Próximo
          <BsChevronRight />
        </Button>
      </section>
    </Box>
  )
}
