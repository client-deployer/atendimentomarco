import { useContext } from "react"
import { useForm, FormProvider } from "react-hook-form"
import { yupResolver } from "@hookform/resolvers/yup"
import { StepForm } from "../../context"
import {
  EigthStep,
  FifthStep,
  FirstStep,
  NinthStep,
  SecondStep,
  SeventhStep,
  SixthStep,
  ThirdStep,
} from "../../features"
import { schema } from "../schemas/schema"
import { IMultiStepForm } from "../../interfaces"
import { FourthStep } from "../FourthStep"

export function MultiStepForm() {
  const { currentStep, currentFormData } = useContext(StepForm)

  const methods = useForm<IMultiStepForm>({
    resolver: yupResolver(schema),
    mode: "onChange",
  })

  const onSubmit = (data: IMultiStepForm) => {
    console.log(data)
    // proximoItemCadastro executar
    // pega o "proximo numero"
    // o item estoque é o proximo numero
    // proximo item cadastro put com o login que mandou no zap
  }

  return (
    <FormProvider {...methods}>
      <form onSubmit={methods.handleSubmit(onSubmit)}>
        {currentStep == 0 ? (
          <FirstStep />
        ) : currentStep == 1 ? (
          <SecondStep />
        ) : currentStep == 2 ? (
          <ThirdStep />
        ) : currentStep == 3 ? (
          <FourthStep />
        ) : currentStep == 4 ? (
          <FifthStep />
        ) : currentStep == 5 ? (
          <SixthStep />
        ) : currentStep == 6 ? (
          <SeventhStep />
        ) : currentStep == 7 ? (
          <EigthStep />
        ) : currentStep == 8 ? (
          <NinthStep />
        ) : (
          <FirstStep />
        )}
      </form>
    </FormProvider>
  )
}
