import { Button, FormInput } from "../../components"
import { BsChevronLeft, BsChevronRight } from "react-icons/bs"
import { Box } from "../../components/Box"
import { useContext, useState } from "react"
import { StepForm } from "../../context"
import { useFormContext } from "react-hook-form"
import { floatMask } from "../utils/masks"
import { IMultiStepForm } from "../../interfaces"

import { FieldSet } from "../SixthStep/styles"
import { CircleNotch } from "phosphor-react"

export function NinthStep() {
  const {
    handleDecreaseStep,
    setCurrentFormData,
    handleIncreaseStep,
    currentFormData,
  } = useContext(StepForm)

  const {
    register,
    setValue,
    formState: { errors },
  } = useFormContext<IMultiStepForm>()

  const [isLoading, setIsLoading] = useState(false)

  return (
    <Box variants="dualButton">
      <h2>Impostos</h2>
      <FormInput
        {...register("aliquotaipi", {
          onChange: (event) => {
            setCurrentFormData({
              ...currentFormData,
              aliquotaipi: event.target.value,
            })
          },
        })}
        label="Alíquota IPI"
        errors={errors && errors.aliquotaipi?.message}
      />
      <FormInput
        {...register("impostoimportacao", {
          onChange: (event) => {
            setCurrentFormData({
              ...currentFormData,
              impostoimportacao: event.target.value,
            })
          },
        })}
        label="Imp. Importação"
        errors={errors && errors.impostoimportacao?.message}
      />
      <FormInput
        {...register("aliqmajor", {
          onChange: (event) => {
            setCurrentFormData({
              ...currentFormData,
              aliqmajor: event.target.value,
            })
          },
        })}
        label="%Aliq. Major. COFINS"
        errors={errors && errors.aliqmajor?.message}
      />
      <FormInput
        {...register("codeantrib", {
          onChange: (event) => {
            setCurrentFormData({
              ...currentFormData,
              codeantrib: event.target.value,
            })
          },
        })}
        label="Código EAN Trib. Gtin"
        errors={errors && errors.grupodesconto?.message}
      />
      <FieldSet>
        <legend>Item estoque</legend>
        {!isLoading ? (
          <CircleNotch size={22} color="#6d6d6d" />
        ) : (
          <span>item</span>
        )}
      </FieldSet>
      <section>
        <Button onClick={() => handleDecreaseStep()}>
          <BsChevronLeft />
          Anterior
        </Button>
        <Button type="submit">Enviar</Button>
      </section>
    </Box>
  )
}
