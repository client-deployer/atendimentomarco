import { Button, FormInput } from "../../components"
import { BsChevronLeft, BsChevronRight } from "react-icons/bs"
import { Box } from "../../components/Box"
import { useContext } from "react"
import { StepForm } from "../../context"
import { useFormContext } from "react-hook-form"
import { floatMask } from "../utils/masks"
import { IMultiStepForm } from "../../interfaces"
import { FieldSet } from "./styles"

export function SixthStep() {
  const {
    handleDecreaseStep,
    setCurrentFormData,
    handleIncreaseStep,
    currentFormData,
  } = useContext(StepForm)

  const {
    register,
    setValue,
    formState: { errors },
  } = useFormContext<IMultiStepForm>()

  return (
    <Box variants="dualButton">
      <h2>Informações do NCM</h2>
      <FieldSet
        {...register("origem", {
          onChange: (event) => {
            setCurrentFormData({
              ...currentFormData,
              origem: event.target.value,
            })
          },
        })}
      >
        <legend>Origem da peça</legend>
        <div>
          <input type="radio" name="origem" id="national" value="national" />
          <label htmlFor="national">N - Nacional</label>
        </div>
        <div>
          <input type="radio" name="origem" id="imported" value="imported" />
          <label htmlFor="national">I - Importado</label>
        </div>
      </FieldSet>
      <FormInput
        {...register("posicaofiscal", {
          onChange: (event) => {
            setCurrentFormData({
              ...currentFormData,
              posicaofiscal: event.target.value,
            })
          },
        })}
        label="Posição fiscal"
        errors={errors && errors.categoria?.message}
      />
      <FormInput
        {...register("cogsegmentoncm", {
          onChange: (event) => {
            setCurrentFormData({
              ...currentFormData,
              cogsegmentoncm: event.target.value,
            })
          },
        })}
        label="Segmento NCM"
        errors={errors && errors.grupo?.message}
      />
      <section>
        <Button onClick={() => handleDecreaseStep()}>
          <BsChevronLeft />
          Anterior
        </Button>
        <Button onClick={() => handleIncreaseStep()}>
          Próximo <BsChevronRight />
        </Button>
      </section>
    </Box>
  )
}
