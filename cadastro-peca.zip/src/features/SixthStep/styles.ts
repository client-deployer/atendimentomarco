import styled from "styled-components"

export const FieldSet = styled.fieldset`
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  border-radius: 4px;

  input[type="radio"] {
    margin: 0;
    padding: 0;
  }

  @keyframes spin {
    from {
      transform: rotate(0deg);
    }
    to {
      transform: rotate(360deg);
    }
  }

  svg {
    animation: spin;
    animation-duration: 1000ms;
    animation-iteration-count: infinite;
    animation-timing-function: linear;
  }

  div {
    display: flex;
    align-items: center;
    gap: 0.5rem;
  }
`
