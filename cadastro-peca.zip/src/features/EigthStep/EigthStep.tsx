import { Button, FormInput } from "../../components"
import { BsChevronLeft, BsChevronRight } from "react-icons/bs"
import { Box } from "../../components/Box"
import { useContext } from "react"
import { StepForm } from "../../context"
import { useFormContext } from "react-hook-form"
import { IMultiStepForm } from "../../interfaces"

export function EigthStep() {
  const {
    handleDecreaseStep,
    setCurrentFormData,
    handleIncreaseStep,
    currentFormData,
  } = useContext(StepForm)

  const {
    register,
    setValue,
    formState: { errors },
  } = useFormContext<IMultiStepForm>()

  return (
    <Box variants="dualButton">
      <h2>Imopostos</h2>
      <FormInput
        {...register("marca", {
          onChange: (event) => {
            setCurrentFormData({
              ...currentFormData,
              marca: event.target.value,
            })
          },
        })}
        label="%Aliq. PIS Imp"
        errors={errors && errors.marca?.message}
      />
      <FormInput
        {...register("pctcofinsimporta", {
          onChange: (event) => {
            setCurrentFormData({
              ...currentFormData,
              pctcofinsimporta: event.target.value,
            })
          },
        })}
        label="%Aliq COFINS Imp."
        errors={errors && errors.pctcofinsimporta?.message}
      />
      <FormInput
        {...register("codeangtin", {
          onChange: (event) => {
            setCurrentFormData({
              ...currentFormData,
              codeangtin: event.target.value,
            })
          },
        })}
        label="Código EAN Gtin"
        errors={errors && errors.codeangtin?.message}
      />
      <section>
        <Button onClick={() => handleDecreaseStep()}>
          <BsChevronLeft />
          Anterior
        </Button>
        <Button onClick={() => handleIncreaseStep()}>
          Próximo
          <BsChevronRight />
        </Button>
      </section>
    </Box>
  )
}
