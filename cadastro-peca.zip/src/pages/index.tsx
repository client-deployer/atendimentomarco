import { StepFormProvider } from "../context"
import { MultiStepForm } from "../features/MultiStepForm/MultiStepForm"

function App() {
  return (
    <StepFormProvider>
      <MultiStepForm />
    </StepFormProvider>
  )
}

export default App
