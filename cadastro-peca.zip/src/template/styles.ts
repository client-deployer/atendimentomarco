import styled from "styled-components"

export const Header = styled.div`
  background-color: #0051b5;
  padding: 0.75rem 1.5rem;

  img {
    max-width: 50px;
  }
`

export const Wrapper = styled.main`
  form {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    min-height: 100%;
    width: 100%;
  }
`
