import { ReactNode } from "react"
import { Header, Wrapper } from "./styles"
import { GlobalStyles } from "../styles/global"

interface ITemplate {
  children: ReactNode
}

export function Template({ children }: ITemplate) {
  return (
    <div>
      <Header>
        <img src="/logo.jpg" alt="Logo Marco Diesel" />
      </Header>
      <Wrapper>{children}</Wrapper>
      <GlobalStyles />
    </div>
  )
}
