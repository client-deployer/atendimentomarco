import { createGlobalStyle } from "styled-components"

export const GlobalStyles = createGlobalStyle`
  body {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: "Nunito";
  }

  ::-webkit-scrollbar {
    width: 8px;
  }

  ::-webkit-scrollbar-track {
    border-radius: 10px;
  }

  ::-webkit-scrollbar-thumb {
    background: #e2e2e2; 
    border-radius: 10px;
  }

  ::-webkit-scrollbar-thumb:hover {
    background: #b30000; 
  }

  ul {
    list-style-type: none;
  }

  input {
    &::-webkit-inner-spin-button, &::-webkit-outer-spin-button {
      -webkit-appearance: none;
      margin: 0;
    }

    &[type=number] {
      -moz-appearance: textfield;
    }
  }

  button {
    outline: none,;
    border: none;
    cursor: pointer;

    &:hover {
      opacity: 0.9,
    }
  }

  h2 {
    font-size: 1.5rem;
    color: #222;
    margin: 0;
  }

  h3 {
    font-size: 1.25rem;
    color: #222;
  }
`
