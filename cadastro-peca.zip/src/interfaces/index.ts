export interface IMultiStepForm {
  codigotributacaoe: string
  itemestoque: number
  codigotributacaos: string
  precopublicoatual: number
  precoavista: number
  precogarantia: number
  // incomeReceipt: any[]
  qtdembalagem: number
  pesoitem: number
  marca: string
  categoria: string
  grupo: string
  grupodesconto: string
  desitemestoque: string
  utilizacao: string
  unidademedida: string
  codigofabrica: string
  origem: "N" | "I"
  posicaofiscal: string
  cogsegmentoncm: string
  basepis: string
  baseconfins: string
  cest: string
  pctpisimporta: number
  pctcofinsimporta: number
  codeangtin: number
  aliquotaipi: number
  impostoimportacao: number
  aliqmajor: number
  codeantrib: number
}

export interface ISampleDataList {
  option: string
  value: number
}
